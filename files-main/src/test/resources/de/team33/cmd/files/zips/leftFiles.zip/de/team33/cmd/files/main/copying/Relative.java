package de.team33.cmd.files.main.copying;

public class Relative {
}
