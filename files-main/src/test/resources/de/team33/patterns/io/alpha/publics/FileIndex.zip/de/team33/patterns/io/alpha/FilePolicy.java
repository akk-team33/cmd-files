package de.team33.patterns.io.alpha;

public enum FilePolicy {

    RESOLVE_SYMLINKS,
    DISTINCT_SYMLINKS;
}
