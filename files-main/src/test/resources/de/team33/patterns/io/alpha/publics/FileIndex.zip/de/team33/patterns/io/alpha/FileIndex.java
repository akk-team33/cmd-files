package de.team33.patterns.io.alpha;

import java.io.File;
import java.nio.file.Path;
import java.util.stream.Stream;

public class FileIndex {

    private final Path path;
    private final FilePolicy policy;

    private FileIndex(final Path path, final FilePolicy policy) {
        this.path = path.toAbsolutePath().normalize();
        this.policy = policy;
    }

    public static FileIndex of(final Path path, final FilePolicy policy) {
        return new FileIndex(path, policy);
    }

    public final Stream<File> files() {
        return streamAll(path.toFile());
    }

    private Stream<File> streamAll(final File[] files) {
        return Stream.of(files)
                     .flatMap(this::streamAll);
    }

    private Stream<File> streamAll(final File file) {
        final Stream<File> head = Stream.of(file);
        if (file.isDirectory()) {
            return Stream.concat(head, streamAll(file.listFiles()));
        } else {
            return head;
        }
    }
}
